(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var FS = Package['cfs:base-package'].FS;
var EJSON = Package.ejson.EJSON;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/cfs_ejson-file/packages/cfs_ejson-file.js                                      //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
(function () {                                                                             // 1
                                                                                           // 2
///////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                   //    // 4
// packages/cfs:ejson-file/fsFile-ejson.js                                           //    // 5
//                                                                                   //    // 6
///////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                     //    // 8
// EJSON custom type                                                                 // 1  // 9
FS.File.prototype.typeName = function() {                                            // 2  // 10
  return 'FS.File';                                                                  // 3  // 11
};                                                                                   // 4  // 12
                                                                                     // 5  // 13
// EJSON equals type                                                                 // 6  // 14
FS.File.prototype.equals = function(other) {                                         // 7  // 15
  var self = this;                                                                   // 8  // 16
  if (other instanceof FS.File) {                                                    // 9  // 17
    return (self._id === other._id && self.collectionName === other.collectionName); // 10
  }                                                                                  // 11
  return false;                                                                      // 12
};                                                                                   // 13
                                                                                     // 14
// EJSON custom clone                                                                // 15
FS.File.prototype.clone = function() {                                               // 16
  return new FS.File(this);                                                          // 17
};                                                                                   // 18
                                                                                     // 19
// EJSON toJSONValue                                                                 // 20
FS.File.prototype.toJSONValue = function() {                                         // 21
  var self = this;                                                                   // 22
  return { _id: self._id, collectionName: self.collectionName };                     // 23
};                                                                                   // 24
                                                                                     // 25
// EJSON fromJSONValue                                                               // 26
FS.File.fromJSONValue = function(value) {                                            // 27
  return new FS.File(value);                                                         // 28
};                                                                                   // 29
                                                                                     // 30
EJSON.addType('FS.File', FS.File.fromJSONValue);                                     // 31
///////////////////////////////////////////////////////////////////////////////////////    // 40
                                                                                           // 41
}).call(this);                                                                             // 42
                                                                                           // 43
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfs:ejson-file'] = {};

})();

//# sourceMappingURL=cfs_ejson-file.js.map
