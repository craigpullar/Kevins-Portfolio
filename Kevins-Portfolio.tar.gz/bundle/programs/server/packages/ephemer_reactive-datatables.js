(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ephemer_reactive-datatables/packages/ephemer_reactive-da //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ephemer:reactive-datatables'] = {};

})();

//# sourceMappingURL=ephemer_reactive-datatables.js.map
