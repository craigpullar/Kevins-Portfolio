(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;

/* Package-scope variables */
var Spiderable;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/gentlenode_spiderable-ssl/packages/gentlenode_spiderable-ssl.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/gentlenode:spiderable-ssl/spiderable.js                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
Spiderable = {};                                                                                                   // 1
                                                                                                                   // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/gentlenode:spiderable-ssl/spiderable_server.js                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var fs = Npm.require('fs');                                                                                        // 1
var child_process = Npm.require('child_process');                                                                  // 2
var querystring = Npm.require('querystring');                                                                      // 3
var urlParser = Npm.require('url');                                                                                // 4
                                                                                                                   // 5
// list of bot user agents that we want to serve statically, but do                                                // 6
// not obey the _escaped_fragment_ protocol. The page is served                                                    // 7
// statically to any client whos user agent matches any of these                                                   // 8
// regexps. Users may modify this array.                                                                           // 9
//                                                                                                                 // 10
// An original goal with the spiderable package was to avoid doing                                                 // 11
// user-agent based tests. But the reality is not enough bots support                                              // 12
// the _escaped_fragment_ protocol, so we need to hardcode a list                                                  // 13
// here. I shed a silent tear.                                                                                     // 14
Spiderable.userAgentRegExps = [                                                                                    // 15
    /^facebookexternalhit/i, /^linkedinbot/i, /^twitterbot/i];                                                     // 16
                                                                                                                   // 17
// how long to let phantomjs run before we kill it                                                                 // 18
var REQUEST_TIMEOUT = 15*1000;                                                                                     // 19
// maximum size of result HTML. node's default is 200k which is too                                                // 20
// small for our docs.                                                                                             // 21
var MAX_BUFFER = 5*1024*1024; // 5MB                                                                               // 22
                                                                                                                   // 23
// Exported for tests.                                                                                             // 24
Spiderable._urlForPhantom = function (siteAbsoluteUrl, requestUrl) {                                               // 25
  // reassembling url without escaped fragment if exists                                                           // 26
  var parsedUrl = urlParser.parse(requestUrl);                                                                     // 27
  var parsedQuery = querystring.parse(parsedUrl.query);                                                            // 28
  delete parsedQuery['_escaped_fragment_'];                                                                        // 29
                                                                                                                   // 30
  var parsedAbsoluteUrl = urlParser.parse(siteAbsoluteUrl);                                                        // 31
  // If the ROOT_URL contains a path, Meteor strips that path off of the                                           // 32
  // request's URL before we see it. So we concatenate the pathname from                                           // 33
  // the request's URL with the root URL's pathname to get the full                                                // 34
  // pathname.                                                                                                     // 35
  if (parsedUrl.pathname.charAt(0) === "/") {                                                                      // 36
    parsedUrl.pathname = parsedUrl.pathname.substring(1);                                                          // 37
  }                                                                                                                // 38
  parsedAbsoluteUrl.pathname = urlParser.resolve(parsedAbsoluteUrl.pathname,                                       // 39
                                                 parsedUrl.pathname);                                              // 40
  parsedAbsoluteUrl.query = parsedQuery;                                                                           // 41
  // `url.format` will only use `query` if `search` is absent                                                      // 42
  parsedAbsoluteUrl.search = null;                                                                                 // 43
                                                                                                                   // 44
  return urlParser.format(parsedAbsoluteUrl);                                                                      // 45
};                                                                                                                 // 46
                                                                                                                   // 47
WebApp.connectHandlers.use(function (req, res, next) {                                                             // 48
  // _escaped_fragment_ comes from Google's AJAX crawling spec:                                                    // 49
  // https://developers.google.com/webmasters/ajax-crawling/docs/specification                                     // 50
  // This spec was designed during the brief era where using "#!" URLs was                                         // 51
  // common, so it mostly describes how to translate "#!" URLs into                                                // 52
  // _escaped_fragment_ URLs. Since then, "#!" URLs have gone out of style, but                                    // 53
  // the <meta name="fragment" content="!"> (see spiderable.html) approach also                                    // 54
  // described in the spec is still common and used by several crawlers.                                           // 55
  if (/\?.*_escaped_fragment_=/.test(req.url) ||                                                                   // 56
      _.any(Spiderable.userAgentRegExps, function (re) {                                                           // 57
        return re.test(req.headers['user-agent']); })) {                                                           // 58
                                                                                                                   // 59
    var url = Spiderable._urlForPhantom(Meteor.absoluteUrl(), req.url);                                            // 60
                                                                                                                   // 61
    // This string is going to be put into a bash script, so it's important                                        // 62
    // that 'url' (which comes from the network) can neither exploit phantomjs                                     // 63
    // or the bash script. JSON stringification should prevent it from                                             // 64
    // exploiting phantomjs, and since the output of JSON.stringify shouldn't                                      // 65
    // be able to contain newlines, it should be unable to exploit bash as                                         // 66
    // well.                                                                                                       // 67
    var phantomScript = "var url = " + JSON.stringify(url) + ";" +                                                 // 68
          "var page = require('webpage').create();" +                                                              // 69
          "page.open(url);" +                                                                                      // 70
          "setInterval(function() {" +                                                                             // 71
          "  var ready = page.evaluate(function () {" +                                                            // 72
          "    if (typeof Meteor !== 'undefined' " +                                                               // 73
          "        && typeof(Meteor.status) !== 'undefined' " +                                                    // 74
          "        && Meteor.status().connected) {" +                                                              // 75
          "      Deps.flush();" +                                                                                  // 76
          "      return DDP._allSubscriptionsReady();" +                                                           // 77
          "    }" +                                                                                                // 78
          "    return false;" +                                                                                    // 79
          "  });" +                                                                                                // 80
          "  if (ready) {" +                                                                                       // 81
          "    var out = page.content;" +                                                                          // 82
          "    out = out.replace(/<script[^>]+>(.|\\n|\\r)*?<\\/script\\s*>/ig, '');" +                            // 83
          "    out = out.replace('<meta name=\"fragment\" content=\"!\">', '');" +                                 // 84
          "    console.log(out);" +                                                                                // 85
          "    phantom.exit();" +                                                                                  // 86
          "  }" +                                                                                                  // 87
          "}, 100);\n";                                                                                            // 88
                                                                                                                   // 89
    // Run phantomjs.                                                                                              // 90
    //                                                                                                             // 91
    // Use '/dev/stdin' to avoid writing to a temporary file. We can't                                             // 92
    // just omit the file, as PhantomJS takes that to mean 'use a                                                  // 93
    // REPL' and exits as soon as stdin closes.                                                                    // 94
    //                                                                                                             // 95
    // However, Node 0.8 broke the ability to open /dev/stdin in the                                               // 96
    // subprocess, so we can't just write our string to the process's stdin                                        // 97
    // directly; see https://gist.github.com/3751746 for the gory details. We                                      // 98
    // work around this with a bash heredoc. (We previous used a "cat |"                                           // 99
    // instead, but that meant we couldn't use exec and had to manage several                                      // 100
    // processes.)                                                                                                 // 101
    child_process.execFile(                                                                                        // 102
      '/bin/bash',                                                                                                 // 103
      ['-c',                                                                                                       // 104
       ("exec phantomjs --ssl-protocol=TLSv1 --ignore-ssl-errors=true --load-images=no /dev/stdin <<'END'\n" +     // 105
        phantomScript + "END\n")],                                                                                 // 106
      {timeout: REQUEST_TIMEOUT, maxBuffer: MAX_BUFFER},                                                           // 107
      function (error, stdout, stderr) {                                                                           // 108
        if (!error && /<html/i.test(stdout)) {                                                                     // 109
          res.writeHead(200, {'Content-Type': 'text/html; charset=UTF-8'});                                        // 110
          res.end(stdout);                                                                                         // 111
        } else {                                                                                                   // 112
          // phantomjs failed. Don't send the error, instead send the                                              // 113
          // normal page.                                                                                          // 114
          if (error && error.code === 127)                                                                         // 115
            Meteor._debug("spiderable: phantomjs not installed. Download and install from http://phantomjs.org/"); // 116
          else                                                                                                     // 117
            Meteor._debug("spiderable: phantomjs failed:", error, "\nstderr:", stderr);                            // 118
                                                                                                                   // 119
          next();                                                                                                  // 120
        }                                                                                                          // 121
      });                                                                                                          // 122
  } else {                                                                                                         // 123
    next();                                                                                                        // 124
  }                                                                                                                // 125
});                                                                                                                // 126
                                                                                                                   // 127
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['gentlenode:spiderable-ssl'] = {}, {
  Spiderable: Spiderable
});

})();

//# sourceMappingURL=gentlenode_spiderable-ssl.js.map
